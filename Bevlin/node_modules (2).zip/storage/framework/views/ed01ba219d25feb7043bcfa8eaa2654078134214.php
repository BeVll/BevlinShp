<h2>Uraaa</h2>
<span>flds;fsdl;</span>
<?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/layouts/mail.blade.php ENDPATH**/ ?>