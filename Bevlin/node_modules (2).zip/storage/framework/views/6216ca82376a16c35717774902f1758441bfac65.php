<?php $__env->startSection('page_content'); ?>



    <div class="xl:max-w-7xl sm:max-w-full main_content_block w-100 mx-auto shadow row  bg-white rounded">
        <div class="profile_menu_div col-3 px-0">
            <div class="w-100">
                <?php echo $__env->make('profile.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


        </div>

        <?php echo $__env->make('profile.partials.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="profile_content_div col-9 m-0 flex px-0 justify-end">
            <div class="vr h-100" style="width: 1px !important;"></div>
            <?php echo $__env->yieldContent('profile_content'); ?>

        </div>

    </div>
    <button class="btn btn-dark w-100 open_profile_menu_btn" data-bs-toggle="offcanvas" data-bs-target="#profileMenu" style="position: fixed; bottom: 0">
        <div class="flex justify-center align-items-center">
            <img src="/storage/icons/buttons_icons/arrowup.png" class=" mr-2" height="20" width="20" alt="">
            <span class=" uppercase" style="">Open profile menu</span>
            <img src="/storage/icons/buttons_icons/arrowup.png" class="ml-2" height="20" width="20" alt="">
        </div>

    </button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../home2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/profile/profile.blade.php ENDPATH**/ ?>