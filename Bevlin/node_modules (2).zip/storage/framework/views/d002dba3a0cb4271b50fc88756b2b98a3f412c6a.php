<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <img src="../../images/logo.png" alt="">
</svg>
<?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/components/application-logo.blade.php ENDPATH**/ ?>