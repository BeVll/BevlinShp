<?php $__env->startSection('page_content'); ?>
<div>

    <ul>
        <?php
           $file = \Illuminate\Support\Facades\Storage::get('example.txt');
           $file2 = \Illuminate\Support\Facades\Storage::download('example.txt');
        ?>
        <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($lang); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li>
                <img class="text-white" src="/storage/icons/categories_icons/<?php echo e($category->icon); ?>" height="50" width="50" alt="">
                <?php if(in_array(App::getLocale(), config('app.available_locales'))): ?>
                    <span><?php echo e($category->{'title_'.App::getLocale()}); ?></span>
                <?php else: ?>
                    <span><?php echo e($category->{'title_'.config('app.fallback_locale')}); ?></span>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php
//

        ?>


    </ul>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../home2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/layouts/main.blade.php ENDPATH**/ ?>