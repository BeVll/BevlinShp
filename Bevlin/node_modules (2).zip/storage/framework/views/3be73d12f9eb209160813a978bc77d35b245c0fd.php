<?php $__env->startSection('page_content'); ?>



    <div class="w-100 sm:max-w-md m-auto px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
        <!-- Session Status -->
        <div class="modal-header">
            <h5 class="modal-title"><?php echo e(__("Sign up")); ?></h5>
        </div>
        <hr>
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mt-3">
                    <label for="firstname" class="form-label"><?php echo e(__("First name")); ?></label>
                    <input type="text" class="form-control" id="firstname" name="firstname">
                    <?php $__errorArgs = ["firstname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mt-3">
                    <label for="lastname" class="form-label"><?php echo e(__("Last name")); ?></label>
                    <input type="text" class="form-control" id="lastname" name="lastname">
                    <?php $__errorArgs = ["lastname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mt-3">
                    <label for="phone" class="form-label"><?php echo e(__("Phone number")); ?></label>
                    <input type="tel" class="form-control" id="phone" name="phone" pattern="[+]{1}[0-9]{12}">
                    <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mt-3">
                    <label for="email" class="form-label"><?php echo e(__("Email")); ?></label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com">
                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mt-3">
                    <label for="password" class="form-label"><?php echo e(__("Password")); ?></label>
                    <input type="password" class="form-control" id="password" name="password">
                    <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



                <div class="flex items-center justify-start mt-4">
                    <button type="submit" class="btn btn-primary py-1">
                        <?php echo e(__('Register')); ?>

                    </button>
                    <a class="underline text-sm text-gray-600 ml-4 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" href="<?php echo e(route('login')); ?>">
                        <?php echo e(__('Already registered?')); ?>

                    </a>


                </div>
            </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../home2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/auth/register.blade.php ENDPATH**/ ?>