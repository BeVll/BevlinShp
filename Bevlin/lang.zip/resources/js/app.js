import './bootstrap';
import * as bootstrap from 'bootstrap'
import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
