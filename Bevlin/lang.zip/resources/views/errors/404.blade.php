@extends('../home2')
@section('page_content')
    <div>
        <h2>Page not found!</h2>
        <a href="/" class="btn btn-primary text-black">{{__("Go to the main page")}}</a>
    </div>

@endsection
