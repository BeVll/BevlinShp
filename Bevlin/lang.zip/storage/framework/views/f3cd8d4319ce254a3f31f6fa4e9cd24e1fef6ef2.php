<?php $__env->startSection('profile_content'); ?>
                <div class="w-100">
                    <ul>
                        <li>1</li>
                        <li>2</li>
                        <li>3</li>
                        <li>4</li>
                        <li>5</li>
                    </ul>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile/profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/profile/orders.blade.php ENDPATH**/ ?>