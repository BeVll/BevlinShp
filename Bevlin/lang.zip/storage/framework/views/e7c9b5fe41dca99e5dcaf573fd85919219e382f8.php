<?php $__env->startSection('page_content'); ?>
    <div>
        <h2>Page not found!</h2>
        <a href="/" class="btn btn-primary text-black"><?php echo e(__("Go to the main page")); ?></a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../home2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/errors/404.blade.php ENDPATH**/ ?>