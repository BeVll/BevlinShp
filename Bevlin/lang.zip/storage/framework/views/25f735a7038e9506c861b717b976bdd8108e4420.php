<div class="offcanvas offcanvas-bottom h-100 p-0" tabindex="-1" id="profileMenu" aria-labelledby="profileMenuLabel">
    <div class="offcanvas-header bg-dark text-white">
        <a href="/"><img class="logo_img" width="44" height="40" src="../images/logo.png" alt=""></a>

        <h5 class="offcanvas-title" id="profileMenuLabel" style="font-family: NUSAR; font-size: 25px; padding-top: 7px">PROFILE MENU</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" style="color: red !important;" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body p-0">
       <?php echo $__env->make('profile.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/profile/partials/profile-menu.blade.php ENDPATH**/ ?>