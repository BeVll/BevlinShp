<ul class="list-group profile_menu">

    <li class="list-group-item <?php if(Route::currentRouteName() == "profile.edit"): ?><?php echo e(("active")); ?><?php endif; ?>">
        <a href="/profile">
            <div class="li_icon">
                <img class="icon_profile_menu" src="/storage/icons/profile_menu/profile2.png" height="30" width="30" alt="">
            </div>
            <span class="ml-2"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?></span>
        </a>
    </li>
    <li class="list-group-item <?php if(Route::currentRouteName() == "profile.orders"): ?><?php echo e(("active")); ?><?php endif; ?>">
        <a href="/profile/orders">
            <div class="li_icon">
                <img class="icon_profile_menu" src="/storage/icons/profile_menu/orders2.png" height="30" width="30" alt="">
            </div>
            <span class="ml-2"><?php echo e(__("My orders")); ?></span>
        </a>
    </li>
    <li class="list-group-item <?php if(Route::currentRouteName() == "profile.wishlist"): ?><?php echo e(("active")); ?><?php endif; ?>">
        <a href="/profile/wishlist">
            <div class="li_icon">
                <img class="icon_profile_menu" src="/storage/icons/profile_menu/wishlist2.png" height="30" width="30" alt="">
            </div>
            <span class="ml-2"><?php echo e(__("Wish list")); ?></span>
        </a>
    </li>
</ul>
<hr class="my-0">
<div class="d-grid gap-1 p-4">
    <form method="POST" class="d-grid gap-1" action="<?php echo e(route("logout")); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-danger "><?php echo e(__('Logout')); ?></button>
    </form>
</div>
<?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/profile/partials/menu.blade.php ENDPATH**/ ?>