<?php $__env->startSection('profile_content'); ?>



                <div class="w-100">
                    <div class="max-w-xl p-4">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <hr class="m-0">
                    <div class="max-w-xl p-4">
                        <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <hr class="m-0">
                    <div class="max-w-xl p-4">
                        <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile/profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/profile/edit.blade.php ENDPATH**/ ?>