<?php $__env->startSection('page_content'); ?>
    <div>
        <h2>Page not found!</h2>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../home2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vladi\PhpstormProjects\BeVlShop\Bevlin\resources\views/layouts/404.blade.php ENDPATH**/ ?>